//: [Previous](@previous)

import Foundation


func runRequest() {
    
    request("") { (items) -> Bool in
        
        // use items
        
        self
        
        return items.count == 10
        
    }
    
    
}

func request(search: String, completion: (items: [AnyObject]) -> Bool) {
    
    
    // runs request
    
    
    
    
    let enoughItems = completion(items: ["item1"])
    
    
    
}



runRequest()



class a {
    
    var b: () -> (){
        
        return { () in
         
            self
            
        }
        
    }
    
    
}


//: [Next](@next)
